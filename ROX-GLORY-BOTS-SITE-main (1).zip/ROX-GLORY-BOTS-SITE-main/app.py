import uuid
import json
import os
import time
import base64
from flask import Flask, render_template_string, request, jsonify, session, redirect
import requests
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = 'god_jexar_projects_ultimate_key_v2026'

# ==========================================
# ⚙️ CONFIGURATION (IMPORTANT SETUP)
# ==========================================
# ⚠️ STEP 1: अपना GitHub Token यहाँ डालें (Vercel Environment Variable में डालना सुरक्षित है)
# GitHub Settings -> Developer Settings -> Personal Access Tokens -> Tokens (classic) -> Generate -> Select 'repo' scope
GITHUB_TOKEN = os.environ.get("GITHUB_TOKEN", "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") 

# ⚠️ STEP 2: अपना Repo Name यहाँ डालें (e.g., "username/reponame")
GITHUB_REPO = "anishsinghofficial/ROX-GLORY-BOTS-SITE" 

# ⚠️ STEP 3: फाइल का नाम जो GitHub पर है
DB_FILE_PATH = "user_data.json"

# App Config
ADMIN_CHAT_ID = "7581974336"
BOT_TOKEN = "8112658412:AAG1x9Thx119UcYy0wbr9Bd1lRNQEYjpORs"
UPI_ID = "9541691780@fam"
BINANCE_ID = "970505083"
SERVER_URL = "https://rox-glory-bots-site.vercel.app"

# ==========================================
# 📦 GITHUB DATABASE MANAGER
# ==========================================
def load_db():
    # If Token is not set, try loading local file (Works only on Localhost)
    if "YOUR_GITHUB_TOKEN" in GITHUB_TOKEN:
        if os.path.exists(DB_FILE_PATH):
            try: return json.load(open(DB_FILE_PATH))
            except: return {"users": {}, "orders": {}}
        return {"users": {}, "orders": {}}

    # Load from GitHub API
    try:
        url = f"https://api.github.com/repos/{GITHUB_REPO}/contents/{DB_FILE_PATH}"
        headers = {"Authorization": f"token {GITHUB_TOKEN}", "Accept": "application/vnd.github.v3+json"}
        resp = requests.get(url, headers=headers)
        if resp.status_code == 200:
            content = base64.b64decode(resp.json()['content']).decode('utf-8')
            return json.loads(content)
    except Exception as e:
        print(f"DB Load Error: {e}")
    return {"users": {}, "orders": {}}

def save_db(data):
    # If Token is not set, try saving locally (Fails on Vercel)
    if "YOUR_GITHUB_TOKEN" in GITHUB_TOKEN:
        try: json.dump(data, open(DB_FILE_PATH, 'w'), indent=4)
        except: pass
        return

    # Save to GitHub API
    try:
        url = f"https://api.github.com/repos/{GITHUB_REPO}/contents/{DB_FILE_PATH}"
        headers = {"Authorization": f"token {GITHUB_TOKEN}", "Accept": "application/vnd.github.v3+json"}
        
        # Step 1: Get current file SHA (Required for update)
        get_resp = requests.get(url, headers=headers)
        sha = get_resp.json().get('sha') if get_resp.status_code == 200 else None
        
        # Step 2: Push new data
        json_str = json.dumps(data, indent=4)
        b64_content = base64.b64encode(json_str.encode('utf-8')).decode('utf-8')
        
        payload = {
            "message": "Update DB via App",
            "content": b64_content,
            "sha": sha
        }
        requests.put(url, headers=headers, json=payload)
    except Exception as e:
        print(f"DB Save Error: {e}")

PRODUCTS = [
    { "id": "p1", "price": 399, "usdt": 4.5, "name": "STARTER PACK", "tag": "HOT", "color": "#FF2D55", "sub": "100k Glory • Instant", "features": ["100k Glory", "Anti-Ban", "2 Hours Validity"] },
    { "id": "p2", "price": 999, "usdt": 11.5, "name": "PRO BOOSTER", "tag": "BEST", "color": "#007AFF", "sub": "400k Glory • Fast", "features": ["400k Glory", "High Speed", "1 Day Validity"] },
    { "id": "p3", "price": 2999, "usdt": 34.0, "name": "GOD MODE", "tag": "VVIP", "color": "#FFD60A", "sub": "Top 10 India Rank", "features": ["Top 10 Rank", "Manager Support", "7 Days Validity"] },
    { "id": "p4", "price": 1999, "usdt": 23.0, "name": "LEVEL UP", "tag": "NEW", "color": "#30D158", "sub": "Level 1 to 7 Max", "features": ["Max Level", "Unlock Slots", "Permanent Stats"] }
]

SETTINGS_IMGS = [
    "https://i.postimg.cc/wB4Qxdcm/IMG-20260107-172944.jpg",
    "https://i.postimg.cc/YqBfCRY7/IMG-20260107-173222.jpg",
    "https://i.postimg.cc/wBMDGG8T/IMG-20260107-173921.jpg"
]

# ==========================================
# 🎨 FRONTEND (HTML/CSS/JS)
# ==========================================
HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>ROX GLORY BOT | FREE FIRE GUILD GLORY</title>
    <link href="https://fonts.googleapis.com/css2?family=Rajdhani:wght@500;600;700&family=Orbitron:wght@700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        :root { --bg: #000000; --glass: rgba(20, 20, 20, 0.65); --border: rgba(255, 255, 255, 0.08); --gold: #FFD700; --blue: #0A84FF; --text: #ffffff; }
        * { margin: 0; padding: 0; box-sizing: border-box; -webkit-tap-highlight-color: transparent; }
        body { background-color: var(--bg); background-image: radial-gradient(circle at 50% 0%, #1a1a1a 0%, #000000 100%); color: var(--text); font-family: 'Rajdhani', sans-serif; min-height: 100vh; padding-bottom: 100px; overflow-x: hidden; }
        
        .glass { background: var(--glass); backdrop-filter: blur(25px); -webkit-backdrop-filter: blur(25px); border: 1px solid var(--border); border-radius: 24px; padding: 20px; margin-bottom: 15px; box-shadow: 0 10px 40px rgba(0,0,0,0.6); position: relative; }
        .page { display: none; padding: 20px; animation: fadeUp 0.4s ease; }
        .page.active { display: block; }
        @keyframes fadeUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }

        .brand-title { font-family: 'Orbitron', sans-serif; font-size: 1.8rem; text-align: center; margin-bottom: 5px; background: linear-gradient(to right, #fff, #888); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
        
        .btn { width: 100%; padding: 16px; border-radius: 16px; border: none; font-weight: 700; font-family: 'Orbitron'; letter-spacing: 1px; cursor: pointer; transition: 0.2s; margin-top: 10px; font-size: 0.9rem; }
        .btn-gold { background: linear-gradient(135deg, #FFD700, #FFA500); color: black; box-shadow: 0 5px 20px rgba(255, 215, 0, 0.2); }
        .btn-blue { background: linear-gradient(135deg, #0A84FF, #0056b3); color: white; box-shadow: 0 5px 20px rgba(10, 132, 255, 0.2); }
        .btn:active { transform: scale(0.97); opacity: 0.9; }

        .input-box { width: 100%; padding: 16px; background: rgba(0,0,0,0.4); border: 1px solid var(--border); border-radius: 14px; color: white; margin-bottom: 12px; outline: none; font-size: 1rem; font-family: 'Rajdhani'; transition: 0.3s; }
        .input-box:focus { border-color: var(--gold); }

        .wallet-card { background: linear-gradient(135deg, #111, #000); border: 1px solid #333; padding: 25px; border-radius: 24px; text-align: center; margin-bottom: 25px; position: relative; overflow: hidden; }
        .wallet-card::after { content:''; position: absolute; top:0; left:0; width:100%; height:100%; background: url('https://www.transparenttextures.com/patterns/carbon-fibre.png'); opacity: 0.05; }
        .wc-bal { font-size: 2.5rem; font-weight: 800; font-family: 'Orbitron'; color: white; margin: 5px 0; }

        .nav-bar { position: fixed; bottom: 20px; left: 50%; transform: translateX(-50%); width: 92%; background: rgba(15, 15, 15, 0.9); backdrop-filter: blur(30px); border-radius: 25px; padding: 10px 20px; display: flex; justify-content: space-between; border: 1px solid var(--border); z-index: 100; box-shadow: 0 10px 40px rgba(0,0,0,0.8); }
        .nav-item { flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: center; color: #666; cursor: pointer; transition: 0.3s; gap: 4px; }
        .nav-item i { font-size: 1.3rem; margin-bottom: 2px; }
        .nav-item span { font-size: 0.65rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; }
        .nav-item.active { color: var(--gold); }
        .nav-item.active span { color: white; }

        .float-container { position: fixed; bottom: 100px; right: 20px; display: flex; flex-direction: column; gap: 15px; z-index: 900; }
        .float-btn { width: 50px; height: 50px; border-radius: 50%; background: rgba(30,30,30,0.9); backdrop-filter: blur(10px); border: 1px solid var(--border); display: flex; align-items: center; justify-content: center; box-shadow: 0 5px 15px rgba(0,0,0,0.5); cursor: pointer; transition: 0.3s; }
        .float-btn:active { transform: scale(0.9); }

        .sheet-overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.8); z-index: 400; display: none; backdrop-filter: blur(5px); }
        .sheet { position: fixed; bottom: 0; left: 0; width: 100%; background: #111; border-radius: 30px 30px 0 0; padding: 25px; z-index: 500; transform: translateY(100%); transition: 0.3s cubic-bezier(0.2, 0.8, 0.2, 1); border-top: 1px solid #333; }
        .sheet.active { transform: translateY(0); }
        .sheet-title { font-family: 'Orbitron'; font-size: 1.2rem; margin-bottom: 20px; color: #ccc; }
        .sheet-opt { background: #1f1f1f; padding: 18px; margin-bottom: 10px; border-radius: 16px; display: flex; align-items: center; justify-content: space-between; border: 1px solid #333; cursor: pointer; }
        .sheet-opt:active { background: #333; }
        
        .pay-tabs { display: flex; gap: 10px; margin-bottom: 20px; background: #111; padding: 5px; border-radius: 12px; }
        .pay-tab { flex: 1; padding: 10px; text-align: center; border-radius: 8px; font-weight: 700; font-size: 0.9rem; color: #666; cursor: pointer; }
        .pay-tab.active { background: #333; color: white; }
    </style>
</head>
<body>
    <div id="toast" style="position:fixed; top:-80px; left:50%; transform:translate(-50%); background:#222; border:1px solid #444; color:white; padding:12px 30px; border-radius:50px; z-index:999; font-weight:700; transition:0.4s; box-shadow:0 10px 40px rgba(0,0,0,0.8); display:flex; gap:10px; align-items:center;"><i class="fas fa-bell" style="color:var(--gold)"></i> <span id="toast-msg">Alert</span></div>

    <div id="p-auth" class="page active" style="padding-top: 15vh; text-align: center;">
        <div style="width: 80px; height: 80px; margin: 0 auto 15px; background: #222; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 2rem; color: var(--gold); border: 2px solid #333;"><i class="fas fa-crown"></i></div>
        <h1 class="brand-title">ROX GLORY BOT</h1>
        <p style="color:#666; margin-bottom: 40px; font-size: 0.9rem; letter-spacing: 2px;">PREMIUM GLORY TOOL</p>
        <div class="glass">
            <div id="auth-login">
                <input id="l-user" class="input-box" placeholder="USERNAME">
                <input id="l-pass" type="password" class="input-box" placeholder="PASSWORD">
                <button class="btn btn-gold" onclick="doLogin()">LOGIN</button>
                <div style="margin-top:20px; font-size:0.8rem; color:#666;" onclick="toggleAuth('signup')">Create Account</div>
            </div>
            <div id="auth-signup" style="display:none;">
                <input id="s-user" class="input-box" placeholder="NEW USERNAME">
                <input id="s-pass" type="password" class="input-box" placeholder="NEW PASSWORD">
                <button class="btn btn-blue" onclick="doSignup()">REGISTER</button>
                <div style="margin-top:20px; font-size:0.8rem; color:#666;" onclick="toggleAuth('login')">Back to Login</div>
            </div>
        </div>
    </div>

    <div id="app-wrapper" style="display:none;">
        
        <div class="float-container">
            <div class="float-btn" onclick="openSelector('help')">
                <i class="fas fa-headset" style="color:#fff; font-size:1.2rem;"></i>
            </div>
            <div class="float-btn" onclick="enableNotif()">
                <i class="fas fa-bell" style="color:var(--gold); font-size:1.2rem;"></i>
            </div>
        </div>

        <div id="p-home" class="page">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
                <div style="font-family:'Orbitron'; font-size:1.2rem;">ROX GLORY <span style="color:var(--gold)">BOT</span></div>
                <div style="font-size:0.8rem; background:#111; padding:5px 12px; border-radius:20px; color:#888;" id="u-name">USER</div>
            </div>
            
            <div class="wallet-card">
                <div style="color:var(--gold); font-size:0.8rem; letter-spacing:1px; font-weight:700;">AVAILABLE CREDITS</div>
                <div id="credit-display" class="wc-bal">0</div>
                <div style="color:#444; font-size:0.8rem;">Tap 'Add Bots' to use credits</div>
            </div>

            {% for p in products %}
            <div class="glass" style="border-left: 3px solid {{p.color}};">
                <div style="position:absolute; top:15px; right:15px; background:{{p.color}}; color:black; font-size:0.7rem; padding:4px 8px; border-radius:6px; font-weight:800;">{{p.tag}}</div>
                <h2 style="font-size:1.4rem; font-weight:800; font-family:'Orbitron';">{{p.name}}</h2>
                <div style="color: #888; margin-bottom: 15px; font-size: 0.9rem;">{{p.sub}}</div>
                <div style="display:flex; gap:10px; flex-wrap:wrap; margin-bottom:15px;">
                    {% for f in p.features %}<span style="font-size:0.75rem; background:#111; padding:4px 10px; border-radius:5px; color:#ccc;">{{f}}</span>{% endfor %}
                </div>
                <div style="display:flex; justify-content:space-between; align-items:center; border-top:1px solid #333; padding-top:15px;">
                    <div style="font-size:1.3rem; font-weight:700;">₹{{p.price}} <span style="font-size:0.8rem; color:#666;">/ ${{p.usdt}}</span></div>
                    <button class="btn" style="width:auto; padding:10px 25px; margin:0; background:#fff; color:#000;" onclick="buyPlan('{{p.id}}', {{p.price}}, {{p.usdt}}, '{{p.name}}')">BUY</button>
                </div>
            </div>
            {% endfor %}
        </div>

        <div id="p-bots" class="page">
            <h1 class="brand-title" style="text-align:left; font-size:1.5rem;">GUILD <span style="color:#fff">TOOLS</span></h1>
            
            <div id="step-settings">
                <div class="glass" style="border-color: #ff453a;">
                    <div style="color:#ff453a; font-weight:800; margin-bottom:10px; font-family:'Orbitron';"><i class="fas fa-exclamation-triangle"></i> REQUIRED SETTINGS</div>
                    <div style="display:grid; gap:10px; margin-bottom:15px;">
                        {% for img in imgs %}
                        <img src="{{img}}" style="width:100%; border-radius:10px; border:1px solid #333;">
                        {% endfor %}
                    </div>
                    <button class="btn btn-gold" onclick="nextStep(2)">I APPLIED SETTINGS</button>
                </div>
            </div>

            <div id="step-form" style="display:none;">
                <div class="glass">
                    <h3 style="margin-bottom:20px; font-family:'Orbitron';">BOT CONFIGURATION</h3>
                    
                    <label style="font-size:0.75rem; color:#888; margin-left:5px;">SELECT PLAN</label>
                    <div class="input-box" onclick="openSelector('plan')" style="display:flex; justify-content:space-between; align-items:center; cursor:pointer;">
                        <span id="disp-plan" style="color:#fff;">Choose Plan Credit...</span> <i class="fas fa-chevron-down" style="color:#666;"></i>
                    </div>
                    <input type="hidden" id="bot-plan-val">

                    <label style="font-size:0.75rem; color:#888; margin-left:5px;">SERVER REGION</label>
                    <div class="input-box" onclick="openSelector('region')" style="display:flex; justify-content:space-between; align-items:center; cursor:pointer;">
                        <span id="disp-region" style="color:#fff;">Select Region...</span> <i class="fas fa-chevron-down" style="color:#666;"></i>
                    </div>
                    <input type="hidden" id="bot-region-val">

                    <label style="font-size:0.75rem; color:#888; margin-left:5px;">GUILD UID</label>
                    <input id="bot-guild" type="number" class="input-box" placeholder="e.g. 30045678">

                    <button class="btn btn-blue" onclick="submitBots()">LAUNCH BOTS 🚀</button>
                    <button class="btn" style="background:transparent; color:#666;" onclick="nextStep(1)">Back</button>
                </div>
            </div>
        </div>

        <div id="p-profile" class="page">
            <h1 class="brand-title" style="text-align:left; font-size:1.5rem;">MY <span style="color:#fff">ORDERS</span></h1>
            <div id="order-list" style="margin-top:20px;"></div>
            <button class="btn" style="background:#222; margin-top:30px;" onclick="location.reload()">LOGOUT</button>
        </div>

        <div class="nav-bar">
            <div class="nav-item active" onclick="nav('p-home', this)">
                <i class="fas fa-store"></i> <span>Shop</span>
            </div>
            <div class="nav-item" onclick="nav('p-bots', this)">
                <i class="fas fa-robot"></i> <span>Add Bots</span>
            </div>
            <div class="nav-item" onclick="nav('p-profile', this)">
                <i class="fas fa-history"></i> <span>History</span>
            </div>
        </div>
    </div>

    <div class="sheet-overlay" id="overlay" onclick="closeSheet()"></div>
    
    <div class="sheet" id="sheet-plan">
        <div class="sheet-title">Select Balance</div>
        <div id="sheet-plan-list"></div>
    </div>

    <div class="sheet" id="sheet-region">
        <div class="sheet-title">Select Region</div>
        <div class="sheet-opt" onclick="selectOpt('region', 'INDIA', '🇮🇳 INDIA')">
            <div>🇮🇳 INDIA SERVER</div> <i class="fas fa-check-circle" style="color:#333;"></i>
        </div>
        <div class="sheet-opt" onclick="selectOpt('region', 'BANGLADESH', '🇧🇩 BANGLADESH')">
            <div>🇧🇩 BANGLADESH SERVER</div> <i class="fas fa-check-circle" style="color:#333;"></i>
        </div>
    </div>

    <div class="sheet" id="sheet-help">
        <div class="sheet-title">Help Center</div>
        <div class="sheet-opt" onclick="window.open('https://t.me/ROXOWNER98')">
            <div style="display:flex; align-items:center; gap:12px; font-weight:700;">
                <i class="fab fa-telegram" style="font-size:1.8rem; color:#229ED9;"></i> Telegram
            </div> 
            <i class="fas fa-external-link-alt" style="color:#666;"></i>
        </div>
        <div class="sheet-opt" onclick="window.open('https://www.instagram.com/godempireff?igsh=b2gwcWhyMmxiZTM2')">
            <div style="display:flex; align-items:center; gap:12px; font-weight:700;">
                <i class="fab fa-instagram" style="font-size:1.8rem; background: -webkit-linear-gradient(#405DE6, #5851DB, #833AB4, #C13584, #E1306C, #FD1D1D); -webkit-background-clip: text; -webkit-text-fill-color: transparent;"></i> Instagram
            </div> 
            <i class="fas fa-external-link-alt" style="color:#666;"></i>
        </div>
    </div>

    <div id="pay-modal" style="position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.95); z-index:900; display:none; flex-direction:column; justify-content:center; padding:20px; backdrop-filter:blur(10px);">
        <div class="glass" style="border:1px solid var(--gold);">
            <div style="text-align:right;"><i class="fas fa-times" onclick="document.getElementById('pay-modal').style.display='none'" style="font-size:1.5rem; cursor:pointer; color:#666;"></i></div>
            
            <h2 id="pay-title" style="text-align:center; font-family:'Orbitron'; margin-bottom:15px;">PURCHASE</h2>
            
            <div class="pay-tabs">
                <div id="tab-upi" class="pay-tab active" onclick="setPayMode('upi')">🇮🇳 UPI</div>
                <div id="tab-bin" class="pay-tab" onclick="setPayMode('binance')">🟡 BINANCE</div>
            </div>

            <div style="text-align:center;">
                <div style="font-size:2rem; font-weight:800; color:var(--gold); margin-bottom:15px;" id="pay-amt">₹0</div>
                <div style="background:white; padding:10px; border-radius:15px; display:inline-block; margin-bottom:20px;">
                    <img id="qr-code" src="" style="width:160px; height:160px; display:block;">
                </div>
                <div id="pay-addr-box" onclick="copyAddr()" style="background:#222; padding:12px; border-radius:10px; font-family:monospace; margin-bottom:20px; border:1px dashed #444; font-size:0.85rem; word-break:break-all;">
                    <span id="pay-addr-txt">Loading...</span> <i class="fas fa-copy" style="color:var(--gold); margin-left:5px;"></i>
                </div>
            </div>
            
            <input id="pay-utr" class="input-box" placeholder="Enter UTR ID">
            <button class="btn btn-gold" onclick="submitPayment()">VERIFY PAYMENT</button>
        </div>
    </div>

    <script>
        const CFG = { upi: "{{ upi }}", binance: "{{ binance }}" };
        let curUser=null, curProd=null, payMode='upi';
        const products = {{ products|tojson }};
        
        function enableNotif() {
            Notification.requestPermission().then(p => {
                if(p==='granted') toast('Notifications Enabled! ✅');
                else toast('Permission Denied ❌');
            });
        }

        function openSelector(type) {
            document.getElementById('overlay').style.display = 'block';
            document.getElementById(`sheet-${type}`).classList.add('active');
            if(type === 'plan') loadPlanSheet();
        }
        function closeSheet() {
            document.getElementById('overlay').style.display = 'none';
            document.querySelectorAll('.sheet').forEach(s => s.classList.remove('active'));
        }
        function selectOpt(type, val, disp) {
            document.getElementById(`bot-${type}-val`).value = val;
            document.getElementById(`disp-${type}`).innerText = disp;
            document.getElementById(`disp-${type}`).style.color = 'var(--gold)';
            closeSheet();
        }
        async function loadPlanSheet() {
            const r = await fetch('/api/user_data'); const d = await r.json();
            const l = document.getElementById('sheet-plan-list'); l.innerHTML = '';
            let has = false;
            if(d.success && d.balance) {
                for (const [pid, qty] of Object.entries(d.balance)) {
                    if(qty > 0) {
                        const p = products.find(x=>x.id===pid);
                        l.innerHTML += `
                        <div class="sheet-opt" onclick="selectOpt('plan', '${pid}', '${p.name} (Credit: ${qty})')">
                            <div>${p.name}</div>
                            <div style="background:#333; padding:2px 10px; border-radius:10px; font-size:0.8rem;">x${qty}</div>
                        </div>`;
                        has = true;
                    }
                }
            }
            if(!has) l.innerHTML = '<div style="text-align:center; color:#555; padding:20px;">No active plans. Buy one from Shop!</div>';
        }

        function buyPlan(id, price, usdt, name) {
            curProd = {id, price, usdt, name};
            document.getElementById('pay-title').innerText = name;
            document.getElementById('pay-modal').style.display='flex';
            setPayMode('upi');
        }
        function setPayMode(m) {
            payMode = m;
            document.querySelectorAll('.pay-tab').forEach(t => t.classList.remove('active'));
            if(m === 'upi') {
                document.getElementById('tab-upi').classList.add('active');
                document.getElementById('pay-amt').innerText = "₹" + curProd.price;
                document.getElementById('pay-addr-txt').innerText = CFG.upi;
                document.getElementById('qr-code').src = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=upi://pay?pa=${CFG.upi}&am=${curProd.price}&pn=GodJexar`;
                document.getElementById('pay-utr').placeholder = "Enter UTR (12 Digits)";
            } else {
                document.getElementById('tab-bin').classList.add('active');
                document.getElementById('pay-amt').innerText = "$" + curProd.usdt + " USDT";
                document.getElementById('pay-addr-txt').innerText = CFG.binance;
                document.getElementById('qr-code').src = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${CFG.binance}`;
                document.getElementById('pay-utr').placeholder = "Enter Binance Order ID";
            }
        }
        function copyAddr() {
            navigator.clipboard.writeText(document.getElementById('pay-addr-txt').innerText);
            toast('Address Copied!');
        }

        function toast(m) { const t=document.getElementById('toast'); document.getElementById('toast-msg').innerText=m; t.style.top='20px'; setTimeout(()=>t.style.top='-80px', 3000); }
        function toggleAuth(m) { document.getElementById('auth-login').style.display=m==='login'?'block':'none'; document.getElementById('auth-signup').style.display=m==='signup'?'block':'none'; }
        
        function nav(pid, el) {
            document.querySelectorAll('.page').forEach(p=>p.classList.remove('active')); document.getElementById(pid).classList.add('active');
            document.querySelectorAll('.nav-item').forEach(i=>i.classList.remove('active')); el.classList.add('active');
            if(pid==='p-home') fetchUserData();
            if(pid==='p-bots') nextStep(1);
            if(pid==='p-profile') fetchHistory();
        }
        function nextStep(s) { document.getElementById('step-settings').style.display=s===1?'block':'none'; document.getElementById('step-form').style.display=s===2?'block':'none'; }

        async function doLogin() {
            const u=document.getElementById('l-user').value, p=document.getElementById('l-pass').value; if(!u||!p)return toast('Fill fields');
            const r=await fetch('/api/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:u,password:p})});
            const d=await r.json(); 
            if(d.success){ 
                curUser=u; document.getElementById('p-auth').classList.remove('active'); document.getElementById('app-wrapper').style.display='block'; document.getElementById('p-home').classList.add('active'); document.getElementById('u-name').innerText=u.toUpperCase(); fetchUserData(); 
            } else {
                toast(d.message);
                if(d.redirect_to_signup) {
                    setTimeout(() => toggleAuth('signup'), 1500);
                }
            }
        }
        async function doSignup() {
            const u=document.getElementById('s-user').value, p=document.getElementById('s-pass').value; if(!u||!p)return toast('Fill fields');
            Swal.fire({title:'Creating...', didOpen:()=>Swal.showLoading(), background:'#111', color:'#fff'});
            const r=await fetch('/api/signup',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:u,password:p})});
            const d=await r.json();
            if(d.success){ Swal.close(); toast('Created! Please Login'); toggleAuth('login'); } else { Swal.close(); toast(d.message); }
        }

        async function fetchUserData() {
            const r=await fetch('/api/user_data'); const d=await r.json();
            if(d.success) {
                let c=0; for(let k in d.balance) c+=d.balance[k];
                document.getElementById('credit-display').innerHTML = c > 0 ? c + " <span style='font-size:1rem; color:#888;'>PLANS</span>" : "0";
            }
        }

        async function submitPayment() {
            const utr = document.getElementById('pay-utr').value; if(!utr) return toast('Enter ID');
            document.getElementById('pay-modal').style.display='none';
            Swal.fire({title:'Verifying...', didOpen:()=>Swal.showLoading(), background:'#111', color:'#fff'});
            const r = await fetch('/api/order', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({type:'payment', pid:curProd.id, utr, method: payMode})});
            if((await r.json()).success) Swal.fire({icon:'success', title:'Sent!', text:'Admin is checking...', background:'#111', color:'#fff'});
        }

        async function submitBots() {
            const pid=document.getElementById('bot-plan-val').value, reg=document.getElementById('bot-region-val').value, guild=document.getElementById('bot-guild').value;
            if(!pid) return toast('Select Plan!'); if(!reg) return toast('Select Region!'); if(!guild) return toast('Enter Guild UID');
            Swal.fire({title:'Sending Bots...', didOpen:()=>Swal.showLoading(), background:'#111', color:'#fff'});
            const r=await fetch('/api/order', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({type:'service', pid, region:reg, guild})});
            const d=await r.json();
            if(d.success) { Swal.fire({icon:'success', title:'Bots Queued', text:'Check Notification', background:'#111', color:'#fff'}); nav('p-home', document.querySelectorAll('.nav-item')[0]); }
            else toast(d.message);
        }

        async function fetchHistory() {
            const r=await fetch('/api/history'); const d=await r.json(); const l=document.getElementById('order-list'); l.innerHTML='';
            if(!d.orders || !d.orders.length) l.innerHTML='<div style="text-align:center;color:#555;">No History</div>';
            else d.orders.forEach(o=>{
                let col = o.status==='completed'?'#30D158':(o.status==='rejected'?'#FF453A':'#FFD60A');
                let sub = o.type==='payment' ? (o.method==='binance' ? 'Binance ID' : 'UTR ID') : 'Guild Bot';
                l.innerHTML+=`<div class="glass" style="display:flex; justify-content:space-between; align-items:center; padding:15px;"><div><div style="font-weight:700;">${o.item_name}</div><div style="font-size:0.75rem; color:#888;">${sub}: ${o.details.utr || o.details.guild}</div></div><div style="color:${col}; font-weight:800; font-size:0.8rem;">${o.status.toUpperCase()}</div></div>`;
            });
        }
    </script>
</body>
</html>
"""

# ==========================================
# 🚀 BACKEND LOGIC
# ==========================================
@app.before_request
def make_session_permanent():
    session.permanent = True

@app.route('/')
def index():
    return render_template_string(HTML_TEMPLATE, products=PRODUCTS, upi=UPI_ID, binance=BINANCE_ID, imgs=SETTINGS_IMGS)

# AUTH
@app.route('/api/signup', methods=['POST'])
def signup():
    d = request.json
    db = load_db()
    if d['username'] in db['users']: return jsonify({'success':False, 'message':'User exists'})
    db['users'][d['username']] = {'password': generate_password_hash(d['password']), 'balance': {}}
    save_db(db)
    return jsonify({'success':True})

@app.route('/api/login', methods=['POST'])
def login():
    d = request.json
    db = load_db()
    u = db['users'].get(d['username'])
    
    # 🔴 Fix: If user does not exist, redirect to signup
    if not u:
        return jsonify({'success':False, 'message':'Account Not Found! Redirecting...', 'redirect_to_signup': True})
    
    if check_password_hash(u['password'], d['password']):
        session['user'] = d['username']
        return jsonify({'success':True})
    return jsonify({'success':False, 'message':'Invalid Credentials'})

@app.route('/api/user_data')
def user_data():
    if 'user' not in session: return jsonify({'success':False})
    db = load_db()
    u = db['users'].get(session['user'], {})
    return jsonify({'success':True, 'balance': u.get('balance', {})})

@app.route('/api/history')
def history():
    if 'user' not in session: return jsonify({'success':False})
    db = load_db()
    u_orders = [v for k,v in db['orders'].items() if v.get('user') == session['user']]
    return jsonify({'orders': u_orders[::-1]})

# ORDERS
@app.route('/api/order', methods=['POST'])
def create_order():
    if 'user' not in session: return jsonify({'success':False})
    data = request.json
    db = load_db()
    oid = str(uuid.uuid4())[:8].upper()
    user = session['user']
    
    pname = next((p['name'] for p in PRODUCTS if p['id'] == data['pid']), "Unknown")

    # Check balance for service
    if data['type'] == 'service':
        bal = db['users'][user].get('balance', {})
        if bal.get(data['pid'], 0) < 1:
            return jsonify({'success':False, 'message':'No Balance'})
        db['users'][user]['balance'][data['pid']] -= 1
        save_db(db)

    order = {
        "id": oid, "user": user, "type": data['type'], "status": "pending",
        "date": time.strftime("%Y-%m-%d %H:%M"), "item_name": pname, "details": data,
        "method": data.get('method', 'upi')
    }
    db['orders'][oid] = order
    save_db(db)
    send_telegram(oid, order)
    return jsonify({'success':True})

def send_telegram(oid, order):
    if order['type'] == 'payment':
        method_txt = "🟡 BINANCE" if order.get('method') == 'binance' else "🇮🇳 UPI"
        id_label = "Binance ID" if order.get('method') == 'binance' else "UTR"
        
        msg = f"""
💰 <b>PAYMENT RECEIVED</b>
➖➖➖➖➖➖➖➖
👤 <b>User:</b> <code>{order['user']}</code>
💳 <b>Method:</b> {method_txt}
📦 <b>Plan:</b> {order['item_name']}
📝 <b>{id_label}:</b> <code>{order['details']['utr']}</code>
➖➖➖➖➖➖➖➖
"""
        btns = {"inline_keyboard": [[{"text": "✅ ADD BALANCE", "url": f"{SERVER_URL}/admin/pay/{oid}/approve"}, {"text": "❌ REJECT", "url": f"{SERVER_URL}/admin/pay/{oid}/reject"}]]}
    else:
        msg = f"""
🎮 <b>BOT REQUEST</b>
➖➖➖➖➖➖➖➖
👤 <b>User:</b> <code>{order['user']}</code>
🌍 <b>Region:</b> {order['details']['region']}
🆔 <b>Guild:</b> <code>{order['details']['guild']}</code>
📉 <b>Used:</b> {order['item_name']}
➖➖➖➖➖➖➖➖
"""
        btns = {"inline_keyboard": [[{"text": "✅ MARK SUCCESS", "url": f"{SERVER_URL}/admin/srv/{oid}/done"}, {"text": "❌ REFUND", "url": f"{SERVER_URL}/admin/srv/{oid}/fail"}]]}

    try: requests.post(f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage", json={"chat_id": ADMIN_CHAT_ID, "text": msg, "parse_mode": "HTML", "reply_markup": btns})
    except: pass

# ADMIN ROUTES
@app.route('/admin/pay/<oid>/<act>')
def admin_pay(oid, act):
    db = load_db()
    order = db['orders'].get(oid)
    if not order or order['status'] != 'pending': return "PROCESSED"
    
    if act == 'approve':
        pid = order['details']['pid']
        user = order['user']
        if 'balance' not in db['users'][user]: db['users'][user]['balance'] = {}
        db['users'][user]['balance'][pid] = db['users'][user]['balance'].get(pid, 0) + 1
        order['status'] = 'completed'
        save_db(db)
        return "<h1>BALANCE ADDED ✅</h1>"
    else:
        order['status'] = 'rejected'
        save_db(db)
        return "<h1>REJECTED ❌</h1>"

@app.route('/admin/srv/<oid>/<act>')
def admin_srv(oid, act):
    db = load_db()
    order = db['orders'].get(oid)
    if not order or order['status'] != 'pending': return "PROCESSED"

    if act == 'done':
        order['status'] = 'completed'
        save_db(db)
        return "<h1>SUCCESS ✅</h1>"
    else:
        pid = order['details']['pid']
        db['users'][order['user']]['balance'][pid] += 1
        order['status'] = 'rejected'
        save_db(db)
        return "<h1>REFUNDED ❌</h1>"

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
